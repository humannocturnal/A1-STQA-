# final_project_2023

Project akhir ini merupakan tugas dari matakuliah multiplatform 
fungsionalitas dan fitur fitur yang ada di project ini yaitu :
1. login untuk masuk kedalam aplikasi
2. terdapat sekilas informasi yang nantinya bisa di update pada halaman utama
3. terdapat halaman untuk lapor tumpukan sampah 
4. terdapat halaman untuk menampilkan data laporan
